#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <malloc.h>

int main(void){
	uint8_t* a = (uint8_t*) malloc(1);
	void * B = malloc(0x10);
	malloc(0xb0);
	a[8+16] = 0x91;
	*(size_t*)(B+0x88) = 0x51;
//	*(size_t*)(B+0xa8) = 0x21;
	free(B);
}
