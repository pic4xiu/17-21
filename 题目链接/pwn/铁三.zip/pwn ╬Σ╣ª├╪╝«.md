## UAF
> 七步杀一人

free(1)
free(2)
feee(1)
malloc(3)
malloc(?)
malloc(?)
malloc(*****)

完成任务
> 3->*****



```
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <malloc.h>

int main(void){
	uint8_t* a = (uint8_t*) malloc(1);
	void * B = malloc(0x10);
	malloc(0x60);
	a[8+16] = 0x91;
	*(size_t*)(B+0x38) = 0x21;
	free(B);
}
```

以为下边直接 top chunk 能泄漏 unsortedbin 地址,忘了直接合并了,23333心里苦
